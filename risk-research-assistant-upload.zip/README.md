# Risk Research Assistant (ML Project)

A machine learning project that predicts a person's **supervision risk level (Low / Medium / High)** from the NIJ recidivism dataset. It compares six models, tunes them with cross-validation, and ends with a small command-line checker where you enter an ID and get the predicted risk level.

> This is a student project for learning. It is **not** a real decision-making tool.

## Project structure

```
risk-research-assistant-ml-project/
├── src/
│   └── risk_research_assistant.py   # full pipeline as a script
├── notebooks/
│   └── risk_research_assistant_ml_project.ipynb
├── data/                            # put NIJ_DataSet.csv here (not tracked)
├── outputs/                         # plots and tables are saved here (not tracked)
├── docs/figures/                    # example result plots
├── requirements.txt
└── README.md
```

## Setup

```bash
git clone https://github.com/roshaanumar/risk-research-assistant-ml-project
cd risk-research-assistant-ml-project
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

Place the dataset at `data/NIJ_DataSet.csv`, then run:

```bash
python src/risk_research_assistant.py
```

Or open the notebook in `notebooks/` (in Colab, upload the CSV and keep the same `data/` path).

## What the pipeline does

1. **Load and clean**: strip text, drop duplicates, drop rows without a risk score (17,698 rows remain).
2. **Target**: risk score 1-4 = Low, 5-7 = Medium, 8-10 = High.
3. **Feature engineering**: ordinal encoding for age, prison time and education; numbers parsed from text counts (e.g. "3 or more"); total prior arrests and convictions.
4. **EDA**: class balance, outliers (IQR rule), histograms, box plots, correlation heatmap.
5. **Split**: 70% train / 30% test, stratified.
6. **Models**: Baseline, Naive Bayes, Logistic Regression, Decision Tree, Random Forest, Gradient Boosting. Tuned with 5-fold `GridSearchCV` on macro F1.
7. **Evaluation**: accuracy, macro precision/recall/F1, ROC-AUC, confusion matrices, ROC and PR curves, feature importance.
8. **Risk checker**: enter an ID to see the predicted level and class probabilities.

Columns that would leak the answer (the risk score itself, supervision level, recidivism outcomes) are removed from the inputs.

## Results (test set)

| Model | Accuracy | F1 (macro) | ROC-AUC |
|---|---|---|---|
| Baseline (majority) | 0.4313 | 0.2009 | 0.5000 |
| Naive Bayes | 0.5019 | 0.5044 | 0.6874 |
| Logistic Regression | 0.6228 | 0.6283 | 0.8029 |
| Decision Tree | 0.5994 | 0.6059 | 0.7726 |
| Random Forest | 0.6143 | 0.6125 | 0.7992 |
| **Gradient Boosting** | **0.6352** | **0.6370** | **0.8125** |

Gradient Boosting had the best cross-validated macro F1 (0.6358) and is used by the checker. Age at release was the most important feature in the Random Forest.

![Confusion matrices](docs/figures/risk_08_confusion_matrices.png)
![Feature importance](docs/figures/risk_09_rf_feature_importance.png)

## Tech

Python, pandas, NumPy, scikit-learn, matplotlib, seaborn.
